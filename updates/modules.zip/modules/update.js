import { app } from "electron";
const extract = require('extract-zip')
var fs = require('fs');

export default class Update {

    static async check() {
        return true;
    }
    static async getVersion() {
        return "1.0.2";
    }
    static async getUpdateDirectory() {
        let dir = await app.getPath('userData');
        let version = await Update.getVersion();
        dir = dir + "/versions/" + version + "/";    
        if (!fs.existsSync(dir)){
            fs.mkdirSync(dir, { recursive: true });
        }
        if (fs.existsSync(dir)) return dir;
        return null;
    }
    static async update() {
        let path = await Update.getUpdateDirectory();
        
        console.log(path);
        return false;
    }
    static async unzip (source, target) {
        try {
          await extract(source, { dir: target })
          console.log('Extraction complete')
        } catch (err) {
          console.log(err);
        }
      }
}