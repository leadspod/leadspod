import { BrowserWindow, ipcMain } from "electron";
import path from "path";
import fs from "fs";

export default class Job {

    static runningBrowserWindow = "runningbrowserwindow";
    static windowIdsMap = {};

    static async setupListners() {
        console.log('hi from pong');
        ipcMain.on('asynchronous-message', (event, arg) => {
            console.log(arg) // prints "ping"
            event.reply('asynchronous-reply', 'pong')
        })
        ipcMain.on('synchronous-message', (event, arg) => {
            console.log(arg) // prints "ping"
            event.returnValue = 'pong'
        })
    }
    static async run(browserWindow, url, script, timeout) {
        var allWindows = browserWindow.getAllWindows();
        for (let index = 0; index < allWindows.length; index++) {
            const window = allWindows[index];
            let windowName = Job.windowIdsMap[window.id];
            if (typeof windowName === 'undefined') {
                Job.windowIdsMap[window.id] = window.getTitle();
            }
        }
        let shouldRun = await Job.runningBrowserWindowInMap(Job.runningBrowserWindow, Job.windowIdsMap);
        if (!shouldRun) {
            Job.setupListners();

            let mainWindow = await Job.startJob(url, timeout);

            Job.addRunningBrowserWindowToMap(mainWindow);

            mainWindow.webContents.once('dom-ready', () => {
                mainWindow.webContents.executeJavaScript(fs.readFileSync(script).toString());
            });

            mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
                try {
                    var msg = JSON.parse(message);
                    if (msg.sender == "intercom") {
                        console.log(msg);
                    }
                } catch (error) {
                }
            });

            mainWindow.on('closed', (event, level, message, line, sourceId) => {
                Job.deleteRunningBrowserWindowFromMap(Job.runningBrowserWindow, Job.windowIdsMap);
            });


        }
    }
    static async startJob(url, timeout) {
        const mainWindow = new BrowserWindow({
            width: 800,
            height: 600,
            show: true,
            webPreferences: {
                nodeIntegration: false,
                contextIsolation: true,
                enableRemoteModule: false,
                preload: path.join(__dirname, "../scripts/preload.js")
            }
        })
        mainWindow.openDevTools();
        mainWindow.loadURL(url)
        setTimeout(function () {
            try {
                mainWindow.close();
            } catch (error) { }
        }, timeout);
        return mainWindow;
    }
    static async runningBrowserWindowInMap(value, map) {
        for (var i in map) {
            if (value == map[i]) return true;
        }
        return false;
    }
    static async addRunningBrowserWindowToMap(mainWindow) {
        Job.windowIdsMap[mainWindow.id] = Job.runningBrowserWindow;
    }
    static async deleteRunningBrowserWindowFromMap(value, map) {
        for (var i in map) {
            if (value == map[i]) {
                delete map[i];
            }
        }
    }
}