const { contextBridge } = require('electron')
const fs = require('fs')
const { ipcRenderer } = require('electron')


contextBridge.exposeInMainWorld('LS', {
  test: () => {
    console.log("hi from preload 2");
    console.log(fs)
  },
  send: () => {
    console.log(ipcRenderer.sendSync('synchronous-message', 'ping')) // prints "pong"
    ipcRenderer.on('asynchronous-reply', (event, arg) => {
      console.log(arg) // prints "pong"
    })
    ipcRenderer.send('asynchronous-message', 'ping')
  }
})

