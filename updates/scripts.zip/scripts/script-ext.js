const ipc = require('electron').ipcRenderer
const BrowserWindow = require('electron').remote.BrowserWindow

ipc.on('compute-factorial', function (event, number, fromWindowId) {
  const fromWindow = BrowserWindow.fromId(fromWindowId)
  const res = document.querySelector('head > title').text;
  fromWindow.webContents.send('factorial-computed', number, res)
  window.close()
})
;0

