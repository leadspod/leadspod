var appRR = async function(){
    //let url = 'https://localhost.prospecting.in/lead/profile/get?_=1593246807399';
    //let response = await fetch(url);   
    //console.log(response);    

    console.log("hi from LI");

    
    setTimeout(function(){
        window.scrollTo(0,document.body.scrollHeight);
    }, 1000);
    setTimeout(function(){
        window.scrollTo(0,document.body.scrollHeight);
    }, 2000);
    setTimeout(function(){
        window.scrollTo(0,document.body.scrollHeight);
    }, 3000);
    setTimeout(function(){
        var nr = document.querySelectorAll('#voyager-feed .occludable-update').length;
        //var name = document.querySelector('.profile-rail-card__actor-link').textContent.trim();
        var msg = {
            sender:"intercom",
            message:"nr : " + nr
        }   
        console.log(JSON.stringify(msg));
    }, 6000);




}
appRR();
;0