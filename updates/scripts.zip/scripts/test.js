var appRR = async function(){
    setTimeout(function(){
        var msg = {
            sender:"intercom",
            message:"test run"
        }   
        console.log(JSON.stringify(msg));
    }, 3000);


    setTimeout(function(){
        console.log("run");
        LS.test();
        LS.send();
    }, 10000);

}
appRR();
;0