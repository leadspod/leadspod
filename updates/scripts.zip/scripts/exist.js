var Exist = async function(){
    setTimeout(function(){
        var msg = {
            sender:"intercom",
            message:"I exist"
        }   
        console.log(JSON.stringify(msg));
    }, 3000);
    async function isTrue() {
        return true;
    }
}
appRR();
;0