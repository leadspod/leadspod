
export default class Test {


    static async check() {
        return true;
    }

}